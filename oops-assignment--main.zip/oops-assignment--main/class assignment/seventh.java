public class seventh {
    public static void main(String args[]){
        int a=23;
        if(a%2==0){
            System.out.println("It is even");
        }
        else{
            System.out.println("It is odd");
        }
    }
}
