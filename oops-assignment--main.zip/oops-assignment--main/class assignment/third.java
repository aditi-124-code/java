public class third {
    public static void main(String args[]){
        Object a=100;
    
        Object frist='A';
        Object e=34.8f;
        Object f=987.34;
        Object g=true;
        System.out.println(a.getClass().getSimpleName());
        
        
        
        System.out.println(frist.getClass().getSimpleName());
        System.out.println(e.getClass().getSimpleName());
        System.out.println(f.getClass().getSimpleName());
        System.out.println(g.getClass().getSimpleName());
    }
}
