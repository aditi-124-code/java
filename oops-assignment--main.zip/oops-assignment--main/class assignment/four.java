public class four {
    public static void main(String args[]){
        double a= 67.89;
        int i= (int)a;
        System.out.println(i);
        char b='A';
        float j=(float)b;
        System.out.println(j);
    }
}
