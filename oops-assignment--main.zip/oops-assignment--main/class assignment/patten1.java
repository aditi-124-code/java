public class patten1 {
    public static void main(String args[]){
        for(int i=0;i<3;i++){
            for (int j=0;j<=i;j++){
                char a=(char)('A'+j);
                System.out.print(a+" ");
            }
            System.out.println();
        }
    }
}
