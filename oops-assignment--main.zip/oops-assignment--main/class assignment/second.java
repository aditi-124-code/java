public class second {
    public static void main(String args[]){
        int a=100;
        short b=34;
        long c=24689434;
        byte d=127;
        char frist='A';
        float e=34.8f;
        double f=987.34;
        boolean g=true;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(frist);
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);
        


    }
}
