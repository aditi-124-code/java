public class eight {
    public static void main(String args[]){
        int a=5;
        int factorial=1;
        for(int i=1;i<=a;i++){
            factorial =i*factorial;

        }
        System.out.println(factorial);
    }
}
