public class five {
    static int a=45;
    static int b=56;
    public static void main(String args[]){
        int c=79;
        int d=65;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }
}
